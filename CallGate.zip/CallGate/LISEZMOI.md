# CallGate : l'appli Téléphone verrouillée par des QCM d'anesthésie-réanimation

## Principe
Quand tu ouvres l'appli **Téléphone** et que le blocage est actif, CallGate affiche un QCM par-dessus.
- Il faut **N bonnes réponses d'affilée** (3 par défaut). Une erreur remet le compteur à zéro.
- Après chaque réponse, tu vois la correction, l'explication et la source.
- Une fois la série réussie, le Téléphone s'ouvre et reste accessible **X minutes** (15 par défaut).
- Pour **désactiver** le blocage, il faut aussi réussir le QCM. Pendant le blocage, les réglages sont verrouillés.

## Sécurités
- **Appels entrants** : l'écran d'appel n'est jamais bloqué, tu peux toujours décrocher (si l'étape 2 est faite).
- **Bouton 🚑 Urgence** : il ouvre le Téléphone 2 minutes sans QCM.
- **Écran verrouillé** : l'appel d'urgence depuis l'écran verrouillé reste toujours possible.

## Installation
1. Installe **Android Studio** : developer.android.com/studio
2. Décompresse `CallGate.zip`, puis *File > Open* et choisis le dossier `CallGate`. Laisse-le télécharger
   ce qui manque. S'il propose de mettre à jour Gradle ou le plugin Android, accepte.
3. Téléphone : *Paramètres > À propos > appuie 7 fois sur « Numéro de build »*, puis
   *Options pour les développeurs > Débogage USB*.
4. Branche le téléphone en USB, sélectionne-le dans Android Studio, puis clique **Run ▶**.
5. Dans CallGate :
   - **Étape 1** : *Ouvrir les réglages d'accessibilité > CallGate > Activer*.
     Si l'option est grisée : *Infos de l'appli CallGate > ⋮ > Autoriser les paramètres restreints*.
   - **Étape 2** : *Autoriser* (détection des appels en cours).
   - Importe ton fichier de QCM, puis *Activer le blocage*.
6. Recommandé : *Paramètres > Batterie > CallGate > Sans restriction* (surtout sur Tecno, Infinix, Xiaomi).

## Format du fichier de QCM (`.json`)
Voir `exemple_qcm.json`. Chaque question contient :
- `question` : l'énoncé ;
- `options` : les propositions (A, B, C…) ;
- `correct` : les numéros des bonnes propositions, **en partant de 0** (0 = A, 1 = B, 2 = C…) ;
- `explication` et `source` : facultatifs, affichés après la réponse.

Pour importer, copie le fichier sur le téléphone (WhatsApp, Drive, câble), puis *Importer un fichier de QCM*.

## Si l'appli Téléphone n'est pas bloquée
Ouvre ton appli Téléphone, reviens dans CallGate. Le nom du paquet apparaît dans « Dernière appli détectée ».
Appuie sur *Ajouter*.

## Limites honnêtes
- Android 10 minimum.
- Tu peux toujours contourner le blocage (désactiver l'accessibilité, désinstaller l'appli) : c'est un garde-fou, pas un coffre-fort.
- Sur Xiaomi, l'appli Téléphone fait partie de l'appli Contacts : bloquer l'une bloque l'autre.
- WhatsApp et les autres applis d'appel ne sont pas bloquées, sauf si tu les ajoutes.
