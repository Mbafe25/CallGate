package com.callgate

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.text.InputType

/** Écran de réglages : activer le blocage, importer les QCM, choisir les applis bloquées. */
class MainActivity : UiActivity() {

    private lateinit var store: Store

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        setupRoot()
        render()
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun isUnlocked() = System.currentTimeMillis() < store.unlockUntil
    private fun canEdit() = !store.enabled || isUnlocked()
    private fun phoneStateGranted() =
        checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED

    private fun render() {
        root.removeAllViews()
        title("CallGate")

        // Étape 1 : service d'accessibilité
        if (Gate.accessibilityOn(this)) {
            para("✅ Détection de l'appli Téléphone active.")
        } else {
            para("⚠️ Étape 1 : active CallGate dans les réglages d'Accessibilité (Applis installées / Services téléchargés).\n" +
                 "Si c'est grisé : Paramètres > Applis > CallGate > ⋮ (en haut à droite) > « Autoriser les paramètres restreints », puis réessaie.")
            button("Ouvrir les réglages d'accessibilité") {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }

        // Étape 2 : permission "état du téléphone" pour ne jamais gêner un appel entrant
        if (phoneStateGranted()) {
            para("✅ Les appels entrants ne seront jamais bloqués.")
        } else {
            para("⚠️ Étape 2 : autorise CallGate à savoir si un appel est en cours, pour que tu puisses toujours décrocher.")
            button("Autoriser") { requestPermissions(arrayOf(Manifest.permission.READ_PHONE_STATE), 2) }
        }

        val status = when {
            !store.enabled -> "Blocage : INACTIF"
            isUnlocked() -> "Blocage : SUSPENDU jusqu'à ${time(store.unlockUntil)}"
            else -> "Blocage : ACTIF"
        }
        title(status, 18f)

        if (!store.enabled) {
            button("Activer le blocage") {
                when {
                    store.questions().isEmpty() -> toast("Importe d'abord un fichier de QCM.")
                    !Gate.accessibilityOn(this) -> toast("Active d'abord CallGate dans l'Accessibilité.")
                    else -> { store.enabled = true; store.unlockUntil = 0L; render() }
                }
            }
        } else {
            if (isUnlocked()) button("Re-bloquer maintenant") { store.unlockUntil = 0L; render() }
            else button("Débloquer le Téléphone (QCM)") { quiz("UNLOCK") }
            button("Désactiver le blocage (QCM)") { quiz("DISABLE") }
        }

        if (canEdit()) renderSettings()
        else para("🔒 Réglages verrouillés pendant le blocage. Réussis le QCM pour les modifier.")
    }

    private fun quiz(action: String) {
        startActivity(Intent(this, QuizActivity::class.java).putExtra("action", action))
    }

    private fun renderSettings() {
        title("Réglages", 18f)
        val num = InputType.TYPE_CLASS_NUMBER
        val minutes = edit("Durée d'accès après un QCM réussi (minutes)", store.unlockMinutes.toString(), num)
        val req = edit("Bonnes réponses d'affilée exigées", store.requiredCorrect.toString(), num)
        button("Enregistrer les réglages") {
            store.unlockMinutes = minutes.text.toString().toIntOrNull()?.coerceIn(1, 720) ?: 15
            store.requiredCorrect = req.text.toString().toIntOrNull()?.coerceIn(1, 20) ?: 3
            toast("Réglages enregistrés")
            render()
        }

        val qs = store.questions()
        title("Banque de QCM : ${qs.size} question(s)", 18f)
        qs.take(3).forEach { para("• ${it.question}") }
        if (qs.size > 3) para("… et ${qs.size - 3} autre(s).")
        button("Importer un fichier de QCM (.json)") {
            startActivityForResult(
                Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), 3
            )
        }

        title("Applis bloquées", 18f)
        Gate.blockedPackages(this, store).sorted().forEach { para("• $it") }
        para("Dernière appli détectée à l'écran : ${store.lastSeenPkg.ifBlank { "—" }}\n" +
             "(Si ton appli Téléphone n'est pas bloquée, ouvre-la, reviens ici et ajoute ce nom.)")
        store.extraPackages().forEach { pkg ->
            row("➕ $pkg") { store.saveExtraPackages(store.extraPackages() - pkg); render() }
        }
        val np = edit("Ajouter une appli à bloquer (nom du paquet)", store.lastSeenPkg)
        button("Ajouter") {
            val pkg = np.text.toString().trim()
            if (pkg.isEmpty() || pkg == packageName) toast("Nom invalide")
            else { store.saveExtraPackages(store.extraPackages() + pkg); render() }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (requestCode == 3 && resultCode == RESULT_OK && uri != null) {
            try {
                val raw = contentResolver.openInputStream(uri)!!.bufferedReader(Charsets.UTF_8).use { it.readText() }
                val bank = Store.parseBank(raw)
                if (bank.isEmpty()) toast("Le fichier ne contient aucune question.")
                else { store.saveBank(raw); toast("${bank.size} question(s) importée(s) ✅") }
            } catch (e: Exception) {
                toast("Fichier invalide : ${e.message}")
            }
        }
        render()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        render()
    }
}
