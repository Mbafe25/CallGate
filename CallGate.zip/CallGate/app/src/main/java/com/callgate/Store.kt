package com.callgate

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings
import android.telecom.TelecomManager
import org.json.JSONArray

/** Une question de QCM : une ou plusieurs bonnes réponses. */
data class Qcm(
    val question: String,
    val options: List<String>,
    val correct: Set<Int>,      // indices des bonnes réponses (0 = A)
    val explication: String,
    val source: String,
)

/** Stockage local de tous les réglages (rien ne quitte le téléphone). */
class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("callgate", Context.MODE_PRIVATE)

    var enabled: Boolean
        get() = p.getBoolean("enabled", false)
        set(v) = p.edit().putBoolean("enabled", v).apply()

    /** Heure (ms) jusqu'à laquelle l'appli Téléphone est accessible. */
    var unlockUntil: Long
        get() = p.getLong("unlockUntil", 0L)
        set(v) = p.edit().putLong("unlockUntil", v).apply()

    var unlockMinutes: Int
        get() = p.getInt("unlockMinutes", 15)
        set(v) = p.edit().putInt("unlockMinutes", v).apply()

    var requiredCorrect: Int
        get() = p.getInt("requiredCorrect", 3)
        set(v) = p.edit().putInt("requiredCorrect", v).apply()

    /** Dernière appli vue au premier plan (pour trouver le nom de l'appli Téléphone). */
    var lastSeenPkg: String
        get() = p.getString("lastSeenPkg", "") ?: ""
        set(v) = p.edit().putString("lastSeenPkg", v).apply()

    fun extraPackages(): List<String> =
        (p.getStringSet("extraPkgs", emptySet()) ?: emptySet()).sorted()

    fun saveExtraPackages(list: List<String>) =
        p.edit().putStringSet("extraPkgs", list.toSet()).apply()

    fun saveBank(raw: String) = p.edit().putString("bank", raw).apply()

    fun questions(): List<Qcm> =
        try { parseBank(p.getString("bank", "[]") ?: "[]") } catch (e: Exception) { emptyList() }

    companion object {
        /** Lit un fichier JSON de QCM. Lève une exception si le format est faux. */
        fun parseBank(raw: String): List<Qcm> {
            val arr = JSONArray(raw)
            return (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val opts = o.getJSONArray("options").let { a -> (0 until a.length()).map { a.getString(it) } }
                val corr = o.getJSONArray("correct").let { a -> (0 until a.length()).map { a.getInt(it) }.toSet() }
                require(opts.size >= 2) { "Question ${i + 1} : il faut au moins 2 propositions" }
                require(corr.isNotEmpty() && corr.all { it in opts.indices }) {
                    "Question ${i + 1} : « correct » doit contenir des numéros entre 0 et ${opts.size - 1}"
                }
                Qcm(
                    question = o.getString("question"),
                    options = opts,
                    correct = corr,
                    explication = o.optString("explication", ""),
                    source = o.optString("source", ""),
                )
            }
        }
    }
}

/** Fonctions utilitaires liées au téléphone. */
object Gate {
    private val KNOWN_DIALERS = setOf(
        "com.google.android.dialer",
        "com.android.dialer",
        "com.samsung.android.dialer",
    )

    fun defaultDialer(ctx: Context): String? =
        ctx.getSystemService(TelecomManager::class.java)?.defaultDialerPackage

    fun blockedPackages(ctx: Context, store: Store): Set<String> =
        KNOWN_DIALERS + store.extraPackages() + listOfNotNull(defaultDialer(ctx))

    /** Vrai si un appel sonne ou est en cours : on ne bloque jamais dans ce cas. */
    fun inCall(ctx: Context): Boolean = try {
        ctx.checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED &&
            ctx.getSystemService(TelecomManager::class.java)?.isInCall == true
    } catch (e: SecurityException) {
        false
    }

    fun accessibilityOn(ctx: Context): Boolean {
        val s = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        return s.contains(ctx.packageName + "/")
    }

    fun openDialer(ctx: Context) {
        ctx.startActivity(Intent(Intent.ACTION_DIAL).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun goHome(ctx: Context) {
        ctx.startActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }
}
