package com.callgate

import android.app.Activity
import android.graphics.Typeface
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Petites briques d'interface partagées par les deux écrans. */
open class UiActivity : Activity() {
    protected lateinit var root: LinearLayout

    protected fun setupRoot() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 60, 40, 60)
        }
        setContentView(ScrollView(this).apply { addView(root) })
    }

    protected fun title(s: String, size: Float = 24f) {
        root.addView(TextView(this).apply {
            text = s; textSize = size
            setTypeface(null, Typeface.BOLD)
            setPadding(0, 32, 0, 12)
        })
    }

    protected fun para(s: String, color: Int? = null): TextView {
        val t = TextView(this).apply {
            text = s; textSize = 15f; setPadding(0, 8, 0, 8)
            if (color != null) setTextColor(color)
        }
        root.addView(t)
        return t
    }

    protected fun button(label: String, onClick: () -> Unit) {
        root.addView(Button(this).apply {
            text = label; isAllCaps = false
            setOnClickListener { onClick() }
        })
    }

    protected fun edit(label: String, value: String, type: Int = InputType.TYPE_CLASS_TEXT): EditText {
        para(label)
        val e = EditText(this).apply { setText(value); inputType = type }
        root.addView(e)
        return e
    }

    protected fun row(s: String, onDelete: () -> Unit) {
        val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        line.addView(TextView(this).apply {
            text = s; textSize = 15f
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        line.addView(Button(this).apply {
            text = "Supprimer"; isAllCaps = false
            setOnClickListener { onDelete() }
        })
        root.addView(line)
    }

    protected fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    protected fun time(ms: Long): String =
        java.text.DateFormat.getTimeInstance(java.text.DateFormat.SHORT).format(java.util.Date(ms))
}
