package com.callgate

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

/**
 * Le "vigile" : à chaque changement de fenêtre, il regarde quelle appli s'ouvre.
 * Si c'est l'appli Téléphone et que le blocage est actif, il affiche le QCM par-dessus.
 */
class GateService : AccessibilityService() {

    private var lastLaunch = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) return

        val store = Store(this)
        if (store.lastSeenPkg != pkg) store.lastSeenPkg = pkg

        if (!store.enabled) return
        val now = System.currentTimeMillis()
        if (now < store.unlockUntil) return
        if (pkg !in Gate.blockedPackages(this, store)) return

        // Jamais de blocage sur l'écran d'un appel entrant ou en cours
        val cls = event.className?.toString() ?: ""
        if (cls.contains("incall", ignoreCase = true) || Gate.inCall(this)) return

        if (now - lastLaunch < 1500) return
        lastLaunch = now
        startActivity(
            Intent(this, QuizActivity::class.java)
                .putExtra("action", "UNLOCK")
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        )
    }

    override fun onInterrupt() {}
}
