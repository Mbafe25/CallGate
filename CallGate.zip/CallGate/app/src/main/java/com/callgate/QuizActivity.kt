package com.callgate

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.CheckBox
import kotlin.random.Random

/** Écran QCM : une série de bonnes réponses d'affilée ouvre l'appli Téléphone. */
class QuizActivity : UiActivity() {

    private lateinit var store: Store
    private var action = "UNLOCK"          // "UNLOCK" ou "DISABLE"
    private var remaining = 0
    private var index = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        setupRoot()
        start(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        start(intent)
    }

    private fun start(i: Intent) {
        action = i.getStringExtra("action") ?: "UNLOCK"
        remaining = store.requiredCorrect
        if (store.questions().isEmpty()) { success(); return }
        nextQuestion()
        renderQuestion()
    }

    private fun nextQuestion() {
        val size = store.questions().size
        if (size <= 1) { index = 0; return }
        var i: Int
        do { i = Random.nextInt(size) } while (i == index)
        index = i
    }

    private fun renderQuestion() {
        root.removeAllViews()
        val q = store.questions()[index]
        title(if (action == "UNLOCK") "🔒 Téléphone verrouillé" else "Désactiver le blocage")
        para("Encore $remaining bonne(s) réponse(s) d'affilée. Une erreur remet le compteur à zéro.")
        title(q.question, 19f)
        para("Coche la ou les bonnes réponses :")

        val boxes = q.options.mapIndexed { i, opt ->
            CheckBox(this).apply { text = "${'A' + i}. $opt"; textSize = 16f }.also { root.addView(it) }
        }

        button("Valider") {
            val chosen = boxes.indices.filter { boxes[it].isChecked }.toSet()
            if (chosen.isEmpty()) { toast("Coche au moins une réponse"); return@button }
            showCorrection(q, boxes, chosen)
        }
        if (action == "UNLOCK") {
            button("🚑 Urgence : ouvrir le Téléphone sans QCM (2 min)") {
                store.unlockUntil = System.currentTimeMillis() + 2 * 60_000L
                Gate.openDialer(this); finish()
            }
        }
        button("Annuler") { cancel() }
    }

    private fun showCorrection(q: Qcm, boxes: List<CheckBox>, chosen: Set<Int>) {
        val ok = chosen == q.correct
        boxes.forEachIndexed { i, b ->
            b.isEnabled = false
            when {
                i in q.correct -> b.setTextColor(Color.rgb(0, 130, 0))
                i in chosen -> b.setTextColor(Color.RED)
            }
        }
        val letters = q.correct.sorted().joinToString(", ") { "${'A' + it}" }
        if (ok) {
            remaining--
            para("✅ Correct ! Bonne(s) réponse(s) : $letters", Color.rgb(0, 130, 0))
        } else {
            remaining = store.requiredCorrect
            para("❌ Faux. Bonne(s) réponse(s) : $letters. Le compteur repart à $remaining.", Color.RED)
        }
        if (q.explication.isNotBlank()) para("💡 ${q.explication}")
        if (q.source.isNotBlank()) para("📚 Source : ${q.source}")

        if (remaining <= 0) {
            button(if (action == "UNLOCK") "Ouvrir le Téléphone" else "Désactiver le blocage") { success() }
        } else {
            button("Question suivante") { nextQuestion(); renderQuestion() }
        }
        button("Annuler") { cancel() }
    }

    private fun success() {
        if (action == "UNLOCK") {
            store.unlockUntil = System.currentTimeMillis() + store.unlockMinutes * 60_000L
            toast("Téléphone accessible jusqu'à ${time(store.unlockUntil)}")
            Gate.openDialer(this)
        } else {
            store.enabled = false
            store.unlockUntil = 0L
            toast("Blocage désactivé")
        }
        finish()
    }

    private fun cancel() {
        if (action == "UNLOCK") Gate.goHome(this)
        finish()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() = cancel()
}
